// Copyright 2013 Google Inc.

#import <Foundation/Foundation.h>

#import <GoogleCast/GCKDefines.h>
#import <GoogleCast/GCKMediaCommon.h>

#ifdef USE_CAST_DYNAMIC_FRAMEWORK
#define GCKMediaStatusClass NSClassFromString(@"GCKMediaStatus")
#endif

@class GCKMediaInformation;
@class GCKMediaQueueItem;

/**
 * @file GCKMediaStatus.h
 * GCKMediaPlayerState and GCKMediaPlayerIdleReason enums.
 */

GCK_ASSUME_NONNULL_BEGIN

/**
 * A flag (bitmask) indicating that a media item can be paused.
 *
 * @memberof GCKMediaStatus
 */
#ifdef USE_CAST_DYNAMIC_FRAMEWORK
#define kGCKMediaCommandPause GCK_EXTERN_NSINTEGER(kGCKMediaCommandPause)
#else
GCK_EXTERN const NSInteger kGCKMediaCommandPause;
#endif

/**
 * A flag (bitmask) indicating that a media item supports seeking.
 *
 * @memberof GCKMediaStatus
 */
#ifdef USE_CAST_DYNAMIC_FRAMEWORK
#define kGCKMediaCommandSeek GCK_EXTERN_NSINTEGER(kGCKMediaCommandSeek)
#else
GCK_EXTERN const NSInteger kGCKMediaCommandSeek;
#endif

/**
 * A flag (bitmask) indicating that a media item's audio volume can be changed.
 *
 * @memberof GCKMediaStatus
 */
#ifdef USE_CAST_DYNAMIC_FRAMEWORK
#define kGCKMediaCommandSetVolume GCK_EXTERN_NSINTEGER(kGCKMediaCommandSetVolume)
#else
GCK_EXTERN const NSInteger kGCKMediaCommandSetVolume;
#endif

/**
 * A flag (bitmask) indicating that a media item's audio can be muted.
 *
 * @memberof GCKMediaStatus
 */

#ifdef USE_CAST_DYNAMIC_FRAMEWORK
#define kGCKMediaCommandToggleMute GCK_EXTERN_NSINTEGER(kGCKMediaCommandToggleMute)
#else
GCK_EXTERN const NSInteger kGCKMediaCommandToggleMute;
#endif

/**
 * A flag (bitmask) indicating that a media item supports skipping forward.
 *
 * @memberof GCKMediaStatus
 */
#ifdef USE_CAST_DYNAMIC_FRAMEWORK
#define kGCKMediaCommandSkipForward GCK_EXTERN_NSINTEGER(kGCKMediaCommandSkipForward)
#else
GCK_EXTERN const NSInteger kGCKMediaCommandSkipForward;
#endif

/**
 * A flag (bitmask) indicating that a media item supports skipping backward.
 *
 * @memberof GCKMediaStatus
 */
#ifdef USE_CAST_DYNAMIC_FRAMEWORK
#define kGCKMediaCommandSkipBackward GCK_EXTERN_NSINTEGER(kGCKMediaCommandSkipBackward)
#else
GCK_EXTERN const NSInteger kGCKMediaCommandSkipBackward;
#endif

/**
 * A flag (bitmask) indicating that a media item supports moving to the next item in the queue.
 *
 * @deprecated This flag is currently not implemented.
 * @memberof GCKMediaStatus
 */
#ifdef USE_CAST_DYNAMIC_FRAMEWORK
#define kGCKMediaCommandQueueNext GCK_EXTERN_NSINTEGER(kGCKMediaCommandQueueNext)
#else
GCK_EXTERN const NSInteger kGCKMediaCommandQueueNext;
#endif

/**
 * A flag (bitmask) indicating that a media item supports moving to the previous item in the
 * queue.
 *
 * @deprecated This flag is currently not implemented.
 * @memberof GCKMediaStatus
 */
#ifdef USE_CAST_DYNAMIC_FRAMEWORK
#define kGCKMediaCommandQueuePrevious GCK_EXTERN_NSINTEGER(kGCKMediaCommandQueuePrevious)
#else
GCK_EXTERN const NSInteger kGCKMediaCommandQueuePrevious;
#endif

/**
 * @enum GCKMediaPlayerState
 * Media player states.
 */
typedef NS_ENUM(NSInteger, GCKMediaPlayerState) {
  /** Constant indicating unknown player state. */
  GCKMediaPlayerStateUnknown = 0,
  /** Constant indicating that the media player is idle. */
  GCKMediaPlayerStateIdle = 1,
  /** Constant indicating that the media player is playing. */
  GCKMediaPlayerStatePlaying = 2,
  /** Constant indicating that the media player is paused. */
  GCKMediaPlayerStatePaused = 3,
  /** Constant indicating that the media player is buffering. */
  GCKMediaPlayerStateBuffering = 4,
};

/**
 * @enum GCKMediaPlayerIdleReason
 * Media player idle reasons.
 */
typedef NS_ENUM(NSInteger, GCKMediaPlayerIdleReason) {
  /** Constant indicating that the player currently has no idle reason. */
  GCKMediaPlayerIdleReasonNone = 0,

  /** Constant indicating that the player is idle because playback has finished. */
  GCKMediaPlayerIdleReasonFinished = 1,

  /**
   * Constant indicating that the player is idle because playback has been cancelled in
   * response to a STOP command.
   */
  GCKMediaPlayerIdleReasonCancelled = 2,

  /**
   * Constant indicating that the player is idle because playback has been interrupted by
   * a LOAD command.
   */
  GCKMediaPlayerIdleReasonInterrupted = 3,

  /** Constant indicating that the player is idle because a playback error has occurred. */
  GCKMediaPlayerIdleReasonError = 4,
};

/**
 * A class that holds status information about some media.
 */
GCK_EXPORT
@interface GCKMediaStatus : NSObject <NSCopying>

/**
 * The media session ID for this item.
 */
@property(nonatomic, assign, readonly) NSInteger mediaSessionID;

/**
 * The current player state.
 */
@property(nonatomic, assign, readonly) GCKMediaPlayerState playerState;

/**
 * Indicates whether the receiver is currently playing an ad.
 */
@property(nonatomic, assign, readonly) BOOL playingAd;

/**
 * The current idle reason. This value is only meaningful if the player state is
 * GCKMediaPlayerStateIdle.
 */
@property(nonatomic, assign, readonly) GCKMediaPlayerIdleReason idleReason;

/**
 * Gets the current stream playback rate. This will be negative if the stream is seeking
 * backwards, 0 if the stream is paused, 1 if the stream is playing normally, and some other
 * postive value if the stream is seeking forwards.
 */
@property(nonatomic, assign, readonly) float playbackRate;

/**
 * The GCKMediaInformation for this item.
 */
@property(nonatomic, strong, readonly, GCK_NULLABLE) GCKMediaInformation *mediaInformation;

/**
 * The current stream position, as an NSTimeInterval from the start of the stream.
 */
@property(nonatomic, assign, readonly) NSTimeInterval streamPosition;

/**
 * The stream's volume.
 */
@property(nonatomic, assign, readonly) float volume;

/**
 * The stream's mute state.
 */
@property(nonatomic, assign, readonly) BOOL isMuted;

/**
 * The current queue repeat mode.
 */
@property(nonatomic, assign, readonly) GCKMediaRepeatMode queueRepeatMode;

/**
 * The ID of the current queue item, if any.
 */
@property(nonatomic, assign, readonly) NSUInteger currentItemID;

/**
 * Whether there is a current item in the queue.
 */
@property(nonatomic, assign, readonly) BOOL queueHasCurrentItem;

/**
 * The current queue item, if any.
 */
@property(nonatomic, assign, readonly, GCK_NULLABLE) GCKMediaQueueItem *currentQueueItem;

/**
 * Checks if there is an item after the currently playing item in the queue.
 */
- (BOOL)queueHasNextItem;

/**
 * The next queue item, if any.
 */
@property(nonatomic, assign, readonly, GCK_NULLABLE) GCKMediaQueueItem *nextQueueItem;

/**
 * Whether there is an item before the currently playing item in the queue.
 */
@property(nonatomic, assign, readonly) BOOL queueHasPreviousItem;

/**
 * Whether there is an item being preloaded in the queue.
 */
@property(nonatomic, assign, readonly) BOOL queueHasLoadingItem;

/**
 * The ID of the item that is currently preloaded, if any.
 */
@property(nonatomic, assign, readonly) NSUInteger preloadedItemID;

/**
 * The ID of the item that is currently loading, if any.
 */
@property(nonatomic, assign, readonly) NSUInteger loadingItemID;

/**
 * The list of active track IDs.
 */
@property(nonatomic, strong, readonly, GCK_NULLABLE) NSArray<NSNumber *> *activeTrackIDs;

/**
 * Any custom data that is associated with the media item.
 */
@property(nonatomic, strong, readonly, GCK_NULLABLE) id customData;

/**
 * Designated initializer.
 *
 * @param mediaSessionID The media session ID.
 * @param mediaInformation The media information.
 */
- (instancetype)initWithSessionID:(NSInteger)mediaSessionID
                 mediaInformation:(GCKMediaInformation * GCK_NULLABLE_TYPE)mediaInformation;

/**
 * Checks if the stream supports a given control command.
 */
- (BOOL)isMediaCommandSupported:(NSInteger)command;

/**
 * Returns the number of items in the playback queue.
 */
- (NSUInteger)queueItemCount;

/**
 * Returns the item at the specified index in the playback queue.
 */
- (GCKMediaQueueItem * GCK_NULLABLE_TYPE)queueItemAtIndex:(NSUInteger)index;

/**
 * Returns the item with the given item ID in the playback queue.
 */
- (GCKMediaQueueItem * GCK_NULLABLE_TYPE)queueItemWithItemID:(NSUInteger)itemID;

/**
 * Returns the index of the item with the given item ID in the playback queue, or -1 if there is
 * no such item in the queue.
 */
- (NSInteger)queueIndexForItemID:(NSUInteger)itemID;

@end

GCK_ASSUME_NONNULL_END
